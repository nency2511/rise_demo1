package pacakge;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ProcessBuilder.Redirect;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class FeedbackServerlet
 */
@WebServlet("/FeedbackServerlet")
public class FeedbackServerlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FeedbackServerlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
	    PrintWriter out = response.getWriter();//
	    String id = request.getParameter("id");//
	    String password = request.getParameter("password");//

	    String url = "jdbc:mysql://127.0.0.1:3306/jdbc";//
	    String username = "root";//
	    String pass = "nency2511";//

	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection conn = DriverManager.getConnection(url, username, pass);
	        
	        if (conn != null) {
	            out.println("Connected successfully ");
	        }
	        
	        	        
	        String sqlinsert = "INSERT INTO emp (name, email, course,rating, comment) VALUES (?, ?, ?,?,?,?)";

	        try (PreparedStatement pstmt = conn.prepareStatement(sqlinsert)) {
	            pstmt.setString(1,username);
	            pstmt.setString(2, email);
	            pstmt.setString(3, city);

	            int rowsInserted = pstmt.executeUpdate();
	            System.out.println(rowsInserted > 0 ? "User inserted successfully!" : "User insertion failed.");
	        } catch (SQLException e) {
	            e.printStackTrace(); // Properly handle SQL exceptions
	        }

	        String sql = "SELECT * FROM servrlet WHERE id = ? AND password = ?";//
	        PreparedStatement ps = conn.prepareStatement(sql);//
	        ps.setString(1, id);//
	        ps.setString(2, password);//

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {//
//	            out.println("Login Successful");//
//	            out.println("Welcome, " + id );//
	        	response.sendRedirect("./FeedBackReview.jsp");
	            
	        } else {//
	        	response.sendRedirect("./FeedBackReview.jsp");
	            out.println("Invalid username or password");//

	        	
	        }//

	        conn.close();//
	    } catch (ClassNotFoundException e) {//
	        out.println("JDBC Driver not found");//
	        e.printStackTrace(out);//
	    } catch (SQLException e) {//
	        out.println(" Database connection failed");//
	        e.printStackTrace(out);//
	    } //
	}

}
